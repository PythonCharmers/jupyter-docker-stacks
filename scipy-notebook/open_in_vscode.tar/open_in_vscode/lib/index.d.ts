import { Widget } from '@lumino/widgets';
import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
import { ABCWidgetFactory, DocumentRegistry, IDocumentWidget, DocumentWidget } from '@jupyterlab/docregistry';
export interface IResponse {
    success: boolean;
}
/**
 * A widget that does not will to live.
 */
export declare class DummyWidget extends Widget {
    protected onAfterAttach(): void;
}
export declare class FileOpenFactory extends ABCWidgetFactory<IDocumentWidget<DummyWidget>> {
    /**
     * Create a new widget factory.
     */
    constructor(options: DocumentRegistry.IWidgetFactoryOptions<IDocumentWidget<DummyWidget>>, app: JupyterFrontEnd);
    /**
     * Create a new widget given a context.
     */
    protected createNewWidget(context: DocumentRegistry.Context): DocumentWidget<DummyWidget>;
    private app;
}
declare const extension: JupyterFrontEndPlugin<void>;
export default extension;
